// import React from 'react';
// import './../SuccessStory/SuccessStoryCard.css'
// import pic2 from "../../assets/AboutPage/coma.png";
// import ChooseUsHeading from '../AboutHeadingText/ChooseUsHeading'


// const SuccessStoryCard = () => {
//     return (

//         <div >


//             <div className='sm:h-743px] lg:h-1743px] sm:mx-auto  ' style={{ height: 743, position: 'relative' }}>





//                 <div style={{ height: 743, left: 0, top: 0, position: 'relative', background: 'white' }} />








//                 <div className="flex relative  lg:w-[598px] sm:w-[650px] lg:h-[485px] w-full h-auto lg:bottom-[598px] lg:left-[330px] mx-auto">
//                     {/* Image */}
//                     <img
//                         className="w-full h-auto object-cover rounded-xl"
//                         src={pic1}
//                         alt="Success Story"
//                     />

//                     {/* Gradient Overlay */}
//                     <div className="absolute bottom-0 left-0 w-full h-1/3 bg-gradient-to-t from-black to-transparent rounded-xl"></div>

//                     {/* Name */}
//                     <div className="absolute bottom-20 left-8 text-white text-lg font-semibold leading-tight">
//                         Albert Flores
//                     </div>

//                     {/* Job Title */}
//                     <div className="absolute bottom-10 left-8 text-gray-400 text-sm font-normal leading-snug">
//                         Product Manager at Jomanar
//                     </div>

//                 </div>

//                 <div className='flex  sm:l-[100px]' style={{ width: 599, height: 433, left: 140, top: 145, position: 'absolute' }}>



//                     <div className="absolute top-[82px] left-0 w-[592px] text-[#090914] lg:text-[28px] sm:text-3xl  font-poppins font-medium leading-[38px] break-words">
//                         {/* Content Here */}



//                         “People now recognise that having a good performance conversation means that something happens as a
//                         result.”
//                     </div>
//                     <div
//                     // style={{ width: 42.28, height: 34.3, left: 0, top: 0, position: 'absolute', background: '#CBD5E1' }}

//                     >

//                         <img src={pic2} alt="" />

//                     </div>   <div style={{ marginBottom: '410px', marginLeft: '100px' }}>
//                         <ChooseUsHeading/>
//                     </div>


//                     <div className="absolute top-[231px] left-0 w-[599px] text-[#52525B] lg:text-[21px] sm:text-2xl font-poppins font-normal leading-[34px] break-words">



//                         “With Landingfolio, the design team can now build design which identifies employees’ career
//                         aspirations and goals and from which we approach managers and check to see what is happening.”
//                     </div>
//                     <div
//                         style={{
//                             width: 193,
//                             height: 32,
//                             padding: 16,
//                             left: 0,
//                             top: 401,
//                             position: 'absolute',
//                             background: 'white',
//                             borderRadius: 50,
//                             flexDirection: 'column',
//                             justifyContent: 'center',
//                             alignItems: 'center',
//                             gap: 10,
//                             display: 'inline-flex'
//                         }}
//                     >
//                         <div style={{ justifyContent: 'center', alignItems: 'center', gap: 9, display: 'inline-flex' }}>
//                             <div
//                                 style={{
//                                     textAlign: 'center',
//                                     color: '#2563EB',
//                                     fontSize: 16,
//                                     fontFamily: 'Poppins',
//                                     fontWeight: '600',
//                                     lineHeight: '28px',
//                                     wordWrap: 'break-word'
//                                 }}
//                             >
//                                 Read Success Story
//                             </div>
//                             <div
//                                 style={{
//                                     transform: 'rotate(-45deg)',
//                                     transformOrigin: '0 0',
//                                     justifyContent: 'center',
//                                     alignItems: 'center',
//                                     gap: 10,
//                                     display: 'flex'
//                                 }}
//                             >
//                                 <div style={{ width: 18, height: 18, position: 'relative' }}>
//                                     <div
//                                         style={{
//                                             width: 13.5,
//                                             height: 10.5,
//                                             left: 2.25,
//                                             top: 3.75,
//                                             position: 'absolute',
//                                             border: '2px #2563EB solid'
//                                         }}
//                                     ></div>
//                                 </div>
//                             </div>
//                         </div>
//                     </div>
//                 </div>
//             </div>



{/* <div style={{ width: 598, height: 485, left: 850, top: 120, position: 'absolute' }}>
                <img
                    style={{ width: 598, height: 485, left: 0, top: 0, position: 'absolute', borderRadius: 20 }}
                    src="https://via.placeholder.com/598x485"
                    alt="Success Story"
                />
                <div
                    style={{
                        width: 598,
                        height: 134,
                        left: 0,
                        top: 351,
                        position: 'absolute',
                        background: 'linear-gradient(360deg, black 0%, rgba(0, 0, 0, 0) 100%)',
                        borderRadius: 20
                    }}
                />
                <div
                    style={{
                        left: 35,
                        top: 409,
                        position: 'absolute',
                        color: 'white',
                        fontSize: 18,
                        fontFamily: 'Poppins',
                        fontWeight: '600',
                        lineHeight: '24px',
                        wordWrap: 'break-word'
                    }}
                >
                    Albert Flores
                </div>
                <div
                    style={{
                        left: 35,
                        top: 437,
                        position: 'absolute',
                        color: '#A1A1AA',
                        fontSize: 14,
                        fontFamily: 'Poppins',
                        fontWeight: '400',
                        lineHeight: '22px',
                        wordWrap: 'break-word'
                    }}
                >
                    Product Manager at Jomanar
                </div>
            </div> */}







{/* 
        </div>

    );
};
 */}


//  import React, { useState } from 'react';
import pic1 from '../././../assets/Mountain/Mountains31.jpg';
import pic2 from '../././../assets/Mountain/Mountains29.jpg';
import pic3 from '../././../assets/Mountain/Mountains30.jpg';
import { FaBolt } from "react-icons/fa6";
import { FaCcAmazonPay } from "react-icons/fa6";
import { FaCompass } from "react-icons/fa6";



import React, { useState } from 'react';

const CustomizableTabs = () => {
    const [activeTab, setActiveTab] = useState('tab1');

    const handleTabClick = (tab) => {
        setActiveTab(tab);
    };

    return (
        <div className="max-w-[80rem] bg-slate-100 rounded-2xl px-4 py-10 sm:px-6 lg:px-8 lg:py-14 mx-auto">
            <div className="relative p-6 md:p-16">
                <div className="relative z-10 lg:grid lg:grid-cols-12 lg:gap-16 lg:items-center">
                    {/* Text Section */}
                    <div className="mb-10 lg:mb-0 lg:col-span-6 lg:col-start-8 lg:order-2">

                        <h2 className="text-3xl lg:mr-40 sm:text-4xl font-extrabold text-gray-800 dark:text-[rgb(46,43,43)] leading-tight tracking-wide sm:text-center">
                            Our Mission
                        </h2>



                        {/* Tab Buttons */}
                        <nav className="grid gap-4 mt-5 md:mt-10" aria-label="Tabs" role="tablist" aria-orientation="vertical">
                            <button
                                type="button"
                                className={`text-start p-4 md:p-5 rounded-xl focus:outline-none ${activeTab === 'tab1' ? 'bg-white shadow-md' : 'hover:bg-gray-200 dark:hover:bg-blue-100'
                                    }`}
                                onClick={() => handleTabClick('tab1')}
                                aria-selected={activeTab === 'tab1'}
                                role="tab"
                            >
                                <span className="flex gap-x-6">
                                    <svg className="shrink-0 mt-2 size-6 md:size-14 text- dark:text-blue-500" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <FaBolt />
                                    </svg>
                                    <span className="grow">
                                        <span className="block lg:text-[1.55rem] md:text-2xl  font-semibold text-blue-800 dark:text-blue-500">
                                            Advanced tools
                                        </span>
                                        <span className="block lg:text-lg md:text-[1.51rem] mt-1 text-gray-800 dark:text-[rgb(46,43,43)]">
                                            Use Preline's automated libraries to manage your businesses.
                                        </span>
                                    </span>
                                </span>
                            </button>

                            <button
                                type="button"
                                className={`text-start p-4 md:p-5 rounded-xl focus:outline-none ${activeTab === 'tab2' ? 'bg-white shadow-md' : 'hover:bg-gray-200 dark:hover:bg-blue-100'
                                    }`}
                                onClick={() => handleTabClick('tab2')}
                                aria-selected={activeTab === 'tab2'}
                                role="tab"
                            >
                                <span className="flex gap-x-6">
                                    <svg className="shrink-0 mt-2 size-6 md:size-14 text-gray-800 dark:text-blue-500" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <FaCompass />

                                    </svg>
                                    <span className="grow">
                                        <span className="block lg:text-[1.55rem] md:text-2xl font-semibold text-gray-800 dark:text-blue-500">
                                            Smart dashboards
                                        </span>
                                        <span className="block lg:text-lg md:text-[1.51rem] mt-1 text-gray-800 dark:text-[rgb(46,43,43)]">
                                            Quickly sample components,copy-paste,and start right off.
                                        </span>
                                    </span>
                                </span>
                            </button>

                            <button
                                type="button"
                                className={`text-start p-4 md:p-5 rounded-xl focus:outline-none ${activeTab === 'tab3' ? 'bg-white shadow-md' : 'hover:bg-gray-200 dark:hover:bg-blue-100'
                                    }`}
                                onClick={() => handleTabClick('tab3')}
                                aria-selected={activeTab === 'tab3'}
                                role="tab"
                            >
                                <span className="flex gap-x-6">
                                    <svg className="shrink-0 mt-2 size-6 md:size-14 text-gray-800 dark:text-blue-500" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <FaCcAmazonPay />

                                    </svg>
                                    <span className="grow">
                                        <span className="block lg:text-[1.55rem] md:text-2xl  font-semibold text-gray-800 dark:text-blue-500">
                                            Powerful features
                                        </span>
                                        <span className="block lg:text-lg md:text-[1.51rem] mt-1 text-gray-800 dark:text-[rgb(46,43,43)]">
                                            Reduce time and effort with Preline's modern design.
                                        </span>
                                    </span>
                                </span>
                            </button>
                        </nav>
                    </div>
                    {/* Image Section */}
                    <div className="lg:col-span-6">
                        <div className="relative">
                            {activeTab === 'tab1' && (
                                <img
                                    className="shadow-xl shadow-gray-200 rounded-xl dark:shadow-gray-900/20"
                                    src={pic1}
                                    alt="Advanced tools"
                                />
                            )}
                            {activeTab === 'tab2' && (
                                <img
                                    className="shadow-xl shadow-gray-200 rounded-xl dark:shadow-gray-900/20"
                                    src={pic2}
                                    alt="Smart dashboards"
                                />
                            )}
                            {activeTab === 'tab3' && (
                                <img
                                    className="shadow-xl shadow-gray-200 rounded-xl dark:shadow-gray-900/20"
                                    src={pic3}
                                    alt="Powerful features"
                                />
                            )}
                        </div>
                    </div>
                </div>
            </div>

        </div>
    );
};

export default CustomizableTabs;
